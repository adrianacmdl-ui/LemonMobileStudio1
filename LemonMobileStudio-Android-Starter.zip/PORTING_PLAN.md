# Plano de porte do motor de áudio

## Fase 0 — protótipo Android
Validar interface, toque e saída de som simples. O `AudioTrack` de teste nesta fase não é o motor Lemon original.

## Fase 1 — inventário de dependências
- Auditar Cargo workspace, `build.rs`, bibliotecas C/C++ e uso de APIs de desktop.
- Classificar cada crate: puro Rust, depende de janela/desktop, depende de biblioteca nativa.
- Identificar o backend de áudio atual e as dependências do renderizador de interface.

## Fase 2 — motor sem interface
- Isolar `os-model`, `os-dsp` e as partes portáveis de `os-engine`.
- Garantir que o motor possa renderizar buffers PCM sem abrir uma janela nem depender de um dispositivo de desktop.
- Criar testes determinísticos de renderização.

## Fase 3 — integração Android
- Adicionar Android NDK e targets Rust para ARM64.
- Criar biblioteca nativa e interface JNI.
- Alimentar saída de áudio em buffers de tamanho controlado.
- Medir latência, consumo de CPU, estalos e estabilidade em aparelho real.

## Fase 4 — recursos
- Carregamento de samples, padrões, piano roll, playlist e mixer.
- Salvar/carregar formato de projeto próprio antes de assumir compatibilidade FLP.
- Importar/exportar WAV.
- Somente depois investigar formatos de plugins e compatibilidade de projetos.

## Critérios para chamar de beta
- Sem travamentos em sessões prolongadas.
- Sem estalos em projeto de referência sob carga definida.
- Projetos salvam e reabrem sem perda.
- Testes de áudio repetíveis.
- Licenças e avisos de terceiros revisados.

# Lemon Mobile Studio (protótipo)

Projeto Android inicial inspirado no Lemon Studio. Destina-se a ser aberto e compilado a partir de um celular Android usando um ambiente de compilação em nuvem.

## O que já existe neste protótipo
- Interface Android em Jetpack Compose.
- Abas Sequencer, Piano Roll e Mixer.
- Grade de 16 passos que pode ser ligada/desligada.
- Controle de BPM na interface.
- Som de teste sintetizado por onda senoidal usando `AudioTrack`.
- Configuração inicial de Gradle e workflow GitHub Actions para gerar APK debug.

## O que ainda NÃO existe
- Não é um porte completo do Lemon Studio.
- O motor de áudio original em Rust ainda não foi integrado.
- O sequenciador ainda não toca automaticamente os passos.
- Não há gravação, importação/exportação de áudio, plugins CLAP/VST, suporte FLP, efeitos reais ou persistência de projetos.
- O controle de volume no mixer é visual e ainda não altera o som.

## Compilar usando apenas o celular
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. Abra a aba **Actions** do repositório e permita workflows, se o GitHub pedir.
3. Execute o workflow **Build Android APK**.
4. Quando terminar, abra a execução e baixe o artefato `lemon-mobile-debug-apk`.
5. Extraia o ZIP baixado e instale o APK no Android. Talvez seja necessário permitir a instalação pelo navegador/gerenciador de arquivos.

O workflow usa um runner Linux hospedado pelo GitHub. O código é editado e enviado pelo celular; a compilação ocorre na nuvem.

## Integração futura do motor Rust
O Lemon Studio original é um workspace Rust com vários crates e dependências específicas de desktop. Não basta adicionar uma dependência Rust para Android: será preciso avaliar cada crate, áudio I/O, janela/renderização e dependências nativas. A estratégia recomendada é:
1. separar o motor de áudio do dispositivo de saída;
2. compilar o núcleo DSP para `aarch64-linux-android`;
3. criar uma camada JNI/NDK para buffers de áudio;
4. usar saída de baixa latência no Android (AAudio/Oboe, após validar compatibilidade);
5. substituir hospedagem VST2/VST3/CLAP de desktop por uma solução Android compatível ou adiar esses formatos;
6. portar e testar recursos em etapas.

## Licença e nome
Este é um protótipo independente inspirado no fluxo de trabalho de uma DAW. O Lemon Studio original é GPL-3.0-or-later. Antes de copiar/adaptar código original, preserve os avisos de copyright, a licença GPL e os avisos de terceiros. Este protótipo não declara ser oficial nem endossado pelos autores do Lemon Studio.

package com.lemonmobile.studio

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

private val Lemon = Color(0xFFB8F34A)
private val Background = Color(0xFF11130F)
private val Panel = Color(0xFF20231D)
private val Muted = Color(0xFF9AA18F)

class MainActivity : ComponentActivity() {
    private var audioTrack: AudioTrack? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LemonStudioScreen(onPlayNote = { hz -> playTone(hz) }) }
    }

    // Starter synth: generates a short sine tone through Android AudioTrack.
    // This is not yet the original Lemon Studio Rust engine.
    private fun playTone(frequency: Double) {
        Thread {
            val sampleRate = 44100
            val durationMs = 260
            val count = sampleRate * durationMs / 1000
            val samples = ShortArray(count)
            for (i in 0 until count) {
                val envelope = minOf(1.0, i / 500.0, (count - i) / 2500.0).coerceAtLeast(0.0)
                samples[i] = (sin(2.0 * PI * frequency * i / sampleRate) * envelope * 9000).toInt().toShort()
            }
            try {
                val minBuffer = AudioTrack.getMinBufferSize(
                    sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(samples.size * 2)
                val track = AudioTrack(
                    AudioManager.STREAM_MUSIC, sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    minBuffer, AudioTrack.MODE_STATIC
                )
                track.write(samples, 0, samples.size)
                track.play()
                Thread.sleep(durationMs.toLong() + 40)
                track.release()
            } catch (_: Exception) {
                // Audio output may be unavailable on an emulator or restricted device.
            }
        }.start()
    }
}

@Composable
private fun LemonStudioScreen(onPlayNote: (Double) -> Unit) {
    var bpm by remember { mutableFloatStateOf(110f) }
    var selectedTab by remember { mutableStateOf("SEQUENCER") }
    var pattern by remember { mutableStateOf(List(16) { it in listOf(0, 4, 8, 12) }) }
    val noteNames = listOf("C", "D", "E", "F", "G", "A", "B", "C")
    val frequencies = listOf(261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25)

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Lemon, background = Background, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Background).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("LEMON", color = Lemon, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("MOBILE STUDIO  •  PROTÓTIPO 0.1", color = Muted, fontSize = 10.sp)
                }
                Text("● PRONTO", color = Lemon, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SEQUENCER", "PIANO ROLL", "MIXER").forEach { tab ->
                    val active = selectedTab == tab
                    Box(
                        Modifier.weight(1f).background(
                            if (active) Lemon else Panel, RoundedCornerShape(10.dp)
                        ).clickable { selectedTab = tab }.padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(tab, color = if (active) Color.Black else Color.White,
                            fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            when (selectedTab) {
                "SEQUENCER" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("BPM", color = Muted, fontSize = 11.sp)
                            Text("${bpm.toInt()}", color = Color.White, fontSize = 25.sp,
                                fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = bpm, onValueChange = { bpm = it },
                            valueRange = 60f..180f, modifier = Modifier.weight(2f)
                        )
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("DRUM PATTERN", color = Lemon, fontWeight = FontWeight.Bold)
                            Text("Toque nos passos para ligar/desligar", color = Muted, fontSize = 11.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                pattern.forEachIndexed { index, enabled ->
                                    Box(
                                        Modifier.weight(1f).height(38.dp)
                                            .background(if (enabled) Lemon else Color(0xFF383D32),
                                                RoundedCornerShape(5.dp))
                                            .clickable {
                                                pattern = pattern.toMutableList().also { it[index] = !it[index] }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("${index + 1}", color = if (enabled) Color.Black else Muted,
                                            fontSize = 10.sp)
                                    }
                                }
                            }
                            Button(
                                onClick = { onPlayNote(130.81) },
                                colors = ButtonDefaults.buttonColors(containerColor = Lemon),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("▶ TESTAR SOM", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("PRÓXIMAS ETAPAS", color = Lemon, fontWeight = FontWeight.Bold)
                            Text("• Transporte de áudio e instrumentos\n• Playlist de padrões\n• Mixer com volume e pan\n• Salvar e abrir projetos", color = Color.White,
                                lineHeight = 22.sp, fontSize = 13.sp)
                        }
                    }
                }
                "PIANO ROLL" -> {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("TECLADO DE TESTE", color = Lemon, fontWeight = FontWeight.Bold)
                            Text("Toque uma nota para ouvir o tom de teste.", color = Muted, fontSize = 11.sp)
                            noteNames.forEachIndexed { i, note ->
                                Row(
                                    Modifier.fillMaxWidth().background(Color(0xFF30352A), RoundedCornerShape(6.dp))
                                        .clickable { onPlayNote(frequencies[i]) }.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(note, color = Lemon, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.width(12.dp))
                                    Text("Nota ${i + 1}", color = Color.White, fontSize = 12.sp)
                                    Spacer(Modifier.weight(1f))
                                    Text("▶", color = Lemon)
                                }
                            }
                        }
                    }
                }
                else -> {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("MASTER", color = Lemon, fontWeight = FontWeight.Bold)
                            Text("Saída principal • protótipo", color = Muted)
                            var volume by remember { mutableFloatStateOf(0.8f) }
                            Text("Volume ${(volume * 100).toInt()}%")
                            Slider(value = volume, onValueChange = { volume = it })
                            Text("O mixer real, roteamento e efeitos ainda precisam ser implementados.", fontSize = 12.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text("PROJETO EXPERIMENTAL • NÃO É O LEMON STUDIO OFICIAL",
                color = Muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}
